export default d => {
  return d;
};
